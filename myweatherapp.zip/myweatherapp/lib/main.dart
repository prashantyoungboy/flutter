import 'package:flutter/material.dart';
import 'package:weather_app/screens/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}

