import 'dart:convert';
import 'package:dio/dio.dart';

class songClient{
  final Dio dio = Dio();
  getSongsFromITunes() async{
    try{
      String iTunesUrl = "https://itunes.apple.com/search?term=lana+del+ray&limit=25";
      var res = await dio.get(iTunesUrl);
      Map<String, dynamic> songsMap =jsonDecode(res.data);
      print("$res");
      print("$songsMap");
      return songsMap;

    }catch(error){
      print("error has occured: $error");
    }
  }


}