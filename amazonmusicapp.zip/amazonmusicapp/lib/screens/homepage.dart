import 'package:cadence/shared/widgets/songstack.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: const Icon(Icons.notifications),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [const Chip(label: Text("MUSIC")), SizedBox(width: MediaQuery.of(context).size.width*0.1), const Chip(label: Text("PODCASTS"))],),
        actions: const [Icon(Icons.settings)],
        centerTitle: true,
        
      ),
      body: 
       SingleChildScrollView(
         child: Column(
          
          children: [
            const Row(children: [
              Text("Trending Playlist",
             style: TextStyle(fontSize: 25, color:Colors.white)
              ),
              Spacer(),
              Chip(label: Text("SEE MORE"))
            ],),
            SizedBox(
              height: MediaQuery.of(context).size.height*0.25,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                children: const [SongStack(imagesrc: 'assets/four.jpg',), SongStack(imagesrc: 'assets/midnights.jpg',), SongStack(imagesrc: 'assets/sour.jpg',), SongStack (imagesrc: 'assets/four.jpg',), SongStack(imagesrc: 'assets/daisy.jpeg',)],)),
                const Row(children: [
              Text("Start a Podcast Habit",
             style: TextStyle(fontSize: 25, color:Colors.white)
              ),
              Spacer(),
              Chip(label: Text("SEE MORE"))
            ],),
            SizedBox(
              height: MediaQuery.of(context).size.height*0.25,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                children: const [SongStack(imagesrc: 'assets/billie.jpg',), SongStack(imagesrc: 'assets/rare.jpg',), SongStack(imagesrc: 'assets/zayn.jpg',), SongStack (imagesrc: 'assets/reputation.jpeg',), SongStack(imagesrc: 'assets/punisher.jpg',)],)),
                const Row(children: [
              Text("Shades of Love",
             style: TextStyle(fontSize: 25, color:Colors.white)
              ),
              Spacer(),
              Chip(label: Text("SEE MORE"))
            ],),
            SizedBox(
              height: MediaQuery.of(context).size.height*0.25,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                children: const [SongStack(imagesrc: 'assets/daisy.jpeg',), SongStack(imagesrc: 'assets/ultraviolence.jpg',), SongStack(imagesrc: 'assets/sour.jpg',), SongStack (imagesrc: 'assets/melodrama.jpg',), SongStack(imagesrc: 'assets/rare.jpg',)],))
                
          ],
             ),
       ),
    ));
  }
}